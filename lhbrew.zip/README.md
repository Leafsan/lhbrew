# Log Horizon TRPG (ログ・ホライズンTRPG) - Foundry VTT
The Github repo for the Log Horizon TRPG system on FoundryVTT

Want to translate this project in your language or see problems/typos? Please help us on [Crowdin](https://crowdin.com/project/lhtrpg/)!
